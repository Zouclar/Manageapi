var express = require('express');
var app = express();
var mysql = require('mysql');
const url = require('url');
var bodyParser = require('body-parser');
var time = require('./time.js');
var orm = require('orm');
var session = require('express-session');

app.use( bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true
}));


app.use(session({
    cookieName: 'session',
    secret: 'manage_api_secret_42',
    duration: 30 * 60 * 1000,
    activeDuration: 5 * 60 * 1000,
    resave: false,
    saveUninitialized: true
}));

/*** Models Creation ***/
app.use(orm.express("mysql://root:toto42@localhost/DB", {
    define: function (db, models, next) {
	
	/* Managers model */
	models.managers = db.define("managers", {
	    name        : String,
	    firstname   : String,
	    mail        : String,
	    password    : String,
	    created_at	: { type: 'date', time: true },
	    modified_at	: { type: 'date', time: true },
	    deleted_at	: { type: 'date', time: true },
	});

	/* Employees model*/
	models.employees = db.define("employees", {
	    name        : String,
	    firstname   : String,
	    mail        : String,
	    created_at	: { type: 'date', time: true },
	    modified_at	: { type: 'date', time: true },
	    deleted_at	: { type: 'date', time: true },
	});

	/* Phrases model*/
	models.phrases = db.define("phrases", {
	    weeks	: String,
	    text        : {type: "text", size: "65000"},
	});

	/* Team model */
	models.teams = db.define("teams", {
	    created_at	: { type: 'date', time: true },
	    modified_at	: { type: 'date', time: true },
	    deleted_at	: { type: 'date', time: true },
	});

	/* Meetings model */
	models.meetings = db.define("meetings", {
	    annual_meeting      : {type: 'date', time: true},
	    mid_annual_meeting  : {type: 'date', time: true},
	    resume              : {type: 'text'},
	    created_at		: { type: 'date', time: true },
	    modified_at		: { type: 'date', time: true },
	    deleted_at		: { type: 'date', time: true },
	});
	
	/* Intermediate model for meetings */
	models.meetings_inter = db.define("meetings_inter", {});
	
	/* Associations */
	models.meetings_inter.hasOne('managers', models.managers, {reverse : "meeting"});
	models.meetings_inter.hasOne('employees', models.employees, {reverse : "meeting"});
	models.meetings_inter.hasOne('teams', models.teams, {reverse : "meeting"});
	models.meetings_inter.hasOne('meetings', models.meetings, {reverse : "meeting"});
	models.employees.hasOne('teams', models.teams, {reverse : "employees"});
	models.teams.hasOne('managers', models.managers, {reverse : "teams"});
	
	
	db.sync(function(err) {
	    if (err) throw err;
	    
	});
	
	next();
    }
}));

/*** Managers routes ***/
app.get('/managers', function(req, res) {
    res.setHeader('Content-Type', 'application/json');
    console.log(req.session.user);
    if (req.session && req.session.mail)
    req.models.managers.find({mail: req.session.mail}, function(err, pers) {
	if (pers)
	{
	    //req.session.user = pers;
	    res.send(200);
	}
	else
	    res.send(400);
    });
});


app.post('/managers/connection', function(req, res) {
    res.setHeader('Content-Type', 'application/json');
    req.models.managers.find({mail: req.body.mail, password: req.body.password}, function(err, pers) {
	if (pers != "")
	{
	    req.session.user = pers;
	    //console.log(req.session.user);
	    res.send(200);
	}
	else
	    res.send(400);
    });
});

app.post('/managers/inscription', function(req, res) {
    //res.setHeader('Content-Type', 'application/json');
    req.models.managers.find({mail: req.body.mail}, function(err, pers) {
	if (pers != "") {
	    console.log("Cette personne existe deja !");
	    res.status(409);
	    res.send("Cette personne existe déjà !");
	}
	else {
	    
	    req.models.managers.create({
		name: req.body.name,
		firstname: req.body.firstname,
		mail: req.body.mail,
		password: req.body.password
	    }, function(err, items) {
		console.log(err);
		req.session.user = items;
		res.status(200);
		res.send(items)
	    });
	}
    });
});


/*app.get('/managers/:mail&:password', function(req, res) {
    res.setHeader('Content-Type', 'application/json');
    console.log(req.params);
    req.models.managers.find({mail: req.params.mail, password: req.params.password}, function(err, pers) {
	if (pers != "") {
	    console.log("Le mail et le mot de passe sont bons !");
	    res.status(200);
	    res.send(pers);
	}
	else {
	    res.status(400);
	    console.log("L'adresse mail et le mot de passe ne correspondent pas !");
	    res.send("L'adresse mail et le mot de passe ne correspondent pas !");
	}
    });
});*/


app.delete('/managers', function(req, res) {
    res.setHeader('Content-Type', 'application/json');
    req.models.managers.get(5, function(err, pers) {
	res.session.reset();
    });
});
/*** End Managers routes ***/


/*** Teams Routes ***/

app.post('/teams', function(req, res){
    res.setHeader('Content-Type', 'application/json');
        req.models.teams.create({
	managers_id: req.body.managers_id,
	created_at: new Date(),
	modified_at: new Date(),
    }, function(err, items) {
	console.log("Teams route erreur : "+err);
	res.send(items);
    });
});

app.get('/teamstomanagers/:id', function(req, res){
    res.setHeader('Content-Type', 'application/json');
    req.models.teams.find({managers_id: req.params.id},function(err, pers) {
	res.json(pers);
    });
});

app.get('/employeesinteams/:id', function(req, res){
    res.setHeader('Content-Type', 'application/json');
    req.models.teams.get(req.params.id,function(err, pers) {
	req.models.employees.find({teams_id: pers.id}, function (err, people) {
	    res.send(people);
	});
    });   
});
/*** END Teams Routes ***/


/*** Employees routes ***/
app.get('/employees', function(req, res) {
    res.setHeader('Content-Type', 'application/json');
    req.models.employees.find(function(err, pers) {
	res.send(pers);
    });
    
});

app.post('/employees', function(req, res) {
    res.setHeader('Content-Type', 'application/json');

    console.log(req.body);
    req.models.employees.create({
	name: req.body.name,
	firstname: req.body.firstname,
	mail: req.body.mail
    }, function(err, items) {
	console.log(err);
	res.send(items);
    });
});


app.get('/employees/:id', function(req, res) {
    res.setHeader('Content-Type', 'application/json');
    req.models.employees.get(req.params.id, function(err, pers) {
	res.send(pers);
    });
});

app.delete('/employees', function(req, res) {
    res.setHeader('Content-Type', 'application/json');
    req.models.employees.get(req.body.mail, function(err, pers) {
	pers.deleted_at = new Date();
	pers.save(function(err) {
	    console.log(err);
	})
	res.send(pers);
    });
});
/*** End Emplyees routes ***/




/*** Meetings routes ***/
app.post('/meetings', function(req, res) {
    res.setHeader('Content-Type', 'application/json');

    console.log(req.body);
    req.models.meetings.create({
	annual_meeting: req.body.annual_meeting,
	mid_annual_meeting: req.body.mid_annual_meeting,
	resume: req.body.resume,
	managers_id: req.body.managers_id,
	employees: req.body.employees_id,
	created_at: new Date(),
	modified_at: new Date()
    }, function(err, items) {
	console.log(err);
	res.send(items);
    });
    
});

app.get('/managersmeetings', function(req, res) {
    res.setHeader('Content-Type', 'application/json');
    req.models.managers(2).getMeeting(function(err, pers) {
	res.send(pers);
    });
});

app.delete('/meetings', function(req, res) {
    res.setHeader('Content-Type', 'application/json');
    req.models.meetings.get(1, function(err, pers) {
	console.log(req.body.id);
	pers.deleted_at = new Date();
	pers.save(function(err) {
	    console.log(err);
	})
	res.send(pers);
    });
});
/*** End Meetings routes ***/

app.get('/logout', function(req, res) {
    req.session.destroy(function(err) {
	if(err) {
	    console.log(err);
	} else {
	    res.redirect('/');
	}
    });
    res.status(200);
    res.send("Déconnexion");
});



app.use(function(req, res, next){
    res.setHeader('Content-Type', 'text/plain');
    res.send(404, 'Page introuvable !');
});

app.listen(3000);
