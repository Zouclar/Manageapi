var schedule = require('node-schedule');
var nodemailer = require('nodemailer');
var mysql      = require('mysql');


var Mailer = function(person, date, type){ // Person, personne à qui envoyer le mail, Date, la date à laquelle l'envoi du mail doit se faire, type 1 pour hebdomadaire 2 pour tous les 6 mois 3 pour les 1 ans;
    //   var date = new Date(2016, 6, 22, 20, 8, 0)
    //    var tbl_user = "novose_s@etna-alternance.net,nakach_t@etna-alternance.net";
    
    
    var rdv = schedule.scheduleJob(date ,function(){	
    var louis;
    var smtpConfig = {
	host: 'smtp.sendgrid.net',
	port: 465,
	secure: true, // use SSL
	auth: {
	    user: 'azure_bff8cd01d09fd68a96204e11c4c10ead@azure.com',
	    pass: 'toto42titi'
	}
    };
    
    var transporter = nodemailer.createTransport(smtpConfig)
    var connection = mysql.createConnection({
	host     : 'localhost',
	user     : 'root',
	password : 'toto42',
	database : 'DB'
    });
    
    connection.connect();

    /*connection.query('select text from phrases where id="'+ getWeekNumber(new Date()) +'"', function(err, rows, fields) {
	if (err) throw err;
	var texte = rows[0].text;
	return texte;
	});*/

    connection.query('select text from phrases where id="'+ getWeekNumber(new Date()) +'"', function(err, rows, fields) {
	if (err) throw err;
	send(rows[0].text);
    });

//    connection.query('select text from phrases where id="'+ getWeekNumber(new Date()) +'"', function(err, rows, fields) {
//	if (err) throw err;
	//send(rows[0].text);
//	console.log(rows[0].text);
  //  });
    
    
    function send(value){

	if (type == 1){
	    var subject = "Introduction à la reunion d'équipe";
	    var text = " vous allez organiser la démarche de l’entretien annuel avec " + person[0] +". <p>Voici un mail préparé pour envoyer à vos équipes.</p><br/><p>Bonjour, <br/>La fin de l’année se termine et il est toujours bon de faire un point sous la forme d’un entretien annuel.<br/>L’objectif est que nous puissions prendre le temps d’aborder de manière constructive votre action et de notre relation au sein de l’entreprise. <br/>L’entretien individuel n’a de sens que s’il est sincère et complet. Son premier objectif est d’améliorer la compréhension réciproque entre nous. Nous allons prendre un « temps privilégié d’expression ». <br/><br/>Quand pourrions nous organiser notre entretien annuel ?<\p>La démarche sera tout d’abord un premier rendez-vous le "+ date +" pour échanger sur l’entretien annuel avec son état d’esprit et ces outils pratiques d’échanges (en pièce jointe).<br/>Puis, nous nous rencontrerons le "+ date2 +" pour échanger concrètement pour établir ensemble un retour de l’année en cours et les objectifs de l’année future pour préparer votre progression de carrière.<br/><br/><p>Merci de regarder avant ce premier rendez-vous les supports en pièce jointe pour préparer les questions ou les demandes.<\p><p>Cordialement, <\p><br/>"+person[0];
	    //var text = "Voici la question de la semaine n° "+ getWeekNumber(new Date())+"<\p>\n<p>"+ rows[0].text + '<\p><br />';
	    
	}
	else if(type == 2){
	    var subject = "Réunion d’équipe : présentation de l’entretien annuel";
	    var text = " vous allez avoir la réunion de présentation de la démarche de l’entretien annuel avec  le "+ date +". <br /><p>N’oublier pas d’imprimer les outils pratiques à l’entretien annuel pour nombre de participants et pour vous.<br />Veuillez trouver ci-dessous exemple de discours pour s’entrainer à cette réunion.<\p>Bonjour, "+ person[0] +", nous allons faire ensemble l’entretient annuel. Es ce que vous savez ce que c’est ? </p><p>L’entretien annuel est un entretien pour que nous fassions ensemble un point sur l’année passée : vos objectifs, vos formations, vos missions. Et programmer les activités pour l’année future.</p><p>Cela dure 30 minutes à une heure. Nous le ferons au calme dans le bureau. <br/>Le but est que je connaisse vos envies et votre volonté dans votre poste voir même ce que vous aimez faire dans l’entreprise, au près des clients et dans les formations. </p><p>L’entretien annuel n’est pas du tout là pour vous critiquer ou vous mettre en situation de faiblesse. L’objectif est que l’on voit ensemble ce que vous voulez faire dans l’avenir chez nous et ce que je voudrais que vous fassiez pour l’entreprise. </p><p>Comment trouvez-vous cela ? Quelles questions avez-vous ? </p><p>Pour cela, je vous laisse un support que vous remplissez tranquillement chez vous. Il sera la trame de notre rendez vous et ne sert que de supports de réflexion pour que vous puissiez préparer l’entretient et les points que l’on va aborder ensemble. Je vous propose que nous le parcourions ensemble.</p><p>Quelles demandes avez-vous ? </p><p> Merci pour cette réunion !</p>";
	}
	else if(type == 3){
	    var subject = "Point 5 min";
	    var text = " prenez le temps de travailler les supports pour le futur entretien annuel de "+ person[0] +".Et veuillez prendre 5 min avec "+ person[0] +"<p> pour lui poser ces questions ci-dessous. </p><p>Il faut être dans l’attitude d’écoute active et de ne pas couper la personne :</p>Bonjour, "+ person [0]+", suite à la réunion de présentation de l’entretien annuel,<p>Comment avez-vous trouvé la réunion ? <br />Quelles questions avez-vous ? <br />Quels points vous bloquent dans le support ? <br />Qu’est ce que vous voudriez me dire ? </p><p>Merci pour ce retour !</p>";
	}
	
	else if(type == 4){
	    var subject = "RDV annuel";
	    var text = " vous allez avoir l’entretien annuel avec "+ person[0] +".<br /><p>N’oubliez pas d’imprimer les outils pratiques à l’entretien annuel pour nombre de participants et pour vous.</p><p>Veuillez trouver ci-dessous exemple de discours pour s’entraîner à cette réunion.</p>Bonjour "+ person[0] +",<p>Nous nous voyons aujourd’hui pour l’entretien annuel. Le but est que l’on travaille mieux ensemble, que l’on progresse ensemble.<br /><br />L’objectif n’est pas de critiquer ou de juger. Il est de voir les points qui ont été travaillés cette année et les points que nous allons travailler ensemble pour l’année future.</p><p>Cela doit se faire dans une idée d’échanges et d’apports. Cela va prendre une demi-heure, mais si l’on dépasse le temps ce n’est pas grave.</p><p>Voyons ensemble le support pour échanger ensemble.</p><p>Comme personne n’est parfait, est-ce que vous voudriez voir quelque chose qui vous gêne dans l’entreprise ? Est-ce que vous voudriez apporter quelque chose à l’entreprise ?<br /><br />Est-ce qu’il a d’autres points que vous voudriez aborder ? A-t-on bien fait le tour ?</p><p>Que pensez-vous de cet entretien ? Est-ce que vous êtes d’accord sur vos objectifs ?</p><p> Merci pour ce retour et cet entretien constructif !</p>";
	}
	
	else if(type == 5){
	    var subject = "Intro rdv de mi-année";
	    var text = " vous allez arriver à la mi-année et c’est le moment de prendre le temps de faire un point avec "+ person[0]  +". <p>Voici un mail préparé pour envoyer à vos équipes.</p><p>Bonjour, <br /><br />Nous arrivons à mi-année et il est toujours bon de faire un point sous la forme d’un entretien. <br /><br />Quand pourrions-nous organiser ce moment ? <br /><br />L’objectif est que nous puissions prendre le temps d’aborder de manière constructive votre action sur l’année en cours et de faire un point sur vos objectifs. <br /><br />L’entretien de mi-année n’a de sens que s’il est sincère et complet. Son premier objectif est d’améliorer la compréhension réciproque entre nous et sur les actions que nous faisons ensemble.<br /><br />Nous nous rencontrerons le "+ date2  +" pour faire un point.<br /><br />Merci de préparer ce rendez-vous à partir de l’entretien annuel et de noter vos actions.<br /><br />Cordialement,</p><br /><br /><br />"+ person [0];
	}
	
	else if(type == 6){
	    var subject = "Point 5 min";
	    var text = " veuillez prendre 5 min avec "+ person[0] +" pour lui poser ces questions ci-dessous. <br /><br />N’oubliez pas de ressortir l’entretien annuel pour lui et pour vous. <br /><br />Il faut être dans l’attitude d’écoute et de ne pas couper la personne : <br /><br />Bonjour "+ person[0]  +", suite à mon mail pour préparer l’entretien de mi-année :<br /><br />Quelles questions avez-vous ? <br /><br />Quels points vous bloquent ? <br /><br />Qu’est ce que vous voudriez me dire ? <br /><p>Merci pour ce retour !</p>";
	}
	
	else if(type == 7){
	    var subject = "Rdv de mi-année";
	    var text = " vous allez avoir l’entretien de mi-année avec "+ person[0]  +".<p><br /><br />N’oubliez pas de ressortir l’entretien annuel pour lui et pour vous. <br /><br />Veuillez trouver ci-dessous exemple de discours pour s’entraîner à cette réunion. </p><p>Bonjour "+ person[0] +", <br /><br />Nous nous voyons aujourd’hui pour l’entretien de mi-année. Le but est que l’on travaille mieux ensemble, que l’on progresse ensemble. <br /><br />L’objectif n’est pas de critiquer ou de juger. Il est de voir les points qui ont été travaillés en ce début d’année et les points que nous allons travailler ensemble pour la fin.<br /><br />Cela doit se faire dans une idée d’échanges et d’apports. Cela va prendre une demi-heure, mais si l’on dépasse le temps ce n’est pas grave.<br /><br />Voyons ensemble le support pour échanger ensemble. <br /><br />Comme personne n’est parfait, est-ce que vous voudriez voir quelque chose qui vous gêne dans l’entreprise ? Est-ce que vous voudriez apporter quelque chose à l’entreprise ? <br /><br />Est ce qu’il a d’autres points que vous voudriez aborder ? A-t-on bien fait le tour ? <br /><br />Que pensez-vous de cet entretien ? Est-ce que vous êtes d’accord sur vos objectifs ?<br /><br /> Merci pour ce retour et cet entretien constructif !<br /><br /></p>";
	}
	else if (type == 8){
	    var subject = "Question de la semaine par Lead Hour";
	    var text = value;
	}
	
	
    for (i in person){	
	var mailOptions = {
	    from: '"Manageappli" <novoseltsev.serguey@gmail.com>', // sender address
	    to: person[i], // list of receivers
	    subject: subject, // Subject line
	    html: "Bonjour "+i+", "+text // html body
	};	
	
	
	transporter.sendMail(mailOptions, function(error, info){
	    if(error){
		return console.log(error);
	    }
	    console.log('Message envoyé: ' + info.response);
	});
    };
	
	connection.end();
    };
    });
};

function getWeekNumber(d) {
    d = new Date(+d);
    d.setHours(0,0,0);
    d.setDate(d.getDate() + 4 - (d.getDay()||7));
    var yearStart = new Date(d.getFullYear(),0,1);
    var weekNo = Math.ceil(( ( (d - yearStart) / 86400000) + 1)/7);
	return (weekNo);
};

//Mailer(({Thomas:"nakach_t@etna-alternance.net", Serguey:"novose_s@etna-alternance.net", Louis:"masurellouis@gmail.com"}), "21 22 * * *", 1);
Mailer(({Thomas:"nakach_t@etna-alternance.net"}), "32 13 * * *", 7);
//Mailer(({Thomas:"nakach_t@etna-alternance.net", Serguey:"novose_s@etna-alternance.net"}), "21 22 * * *", 3);
