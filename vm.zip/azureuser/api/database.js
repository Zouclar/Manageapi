var mysql = require('mysql');
var orm = require('orm');
var express = require('express');
var app = express();
var modts = require('orm-timestamps');

/*** Models Creation ***/
app.use(orm.express("mysql://root:toto42@localhost/DB", {
    define: function (db, models, next) {
	db.use(modts, {
	    createdProperty: 'created_at',
	    modifiedProperty: 'modified_at',
	    expireProperty: "deleted_at",
	    dbtype: { type: 'date', time: true },
	    now: function() { return new Date(); },
	    expire: function() { return null; },
	    persist: true
	});
	
	/* Managers model */
	models.managers = db.define("managers", {
	    name        : String,
	    firstname   : String,
	    mail        : String,
	    password    : String,
	}, {
	    timestamp: true
	});
	
	/* Employees model*/
	models.employees = db.define("employees", {
	    name        : String,
	    firstname   : String,
	    mail        : String,
	}, {
	    timestamp: true
	});
	
	/* Team model */
	models.teams = db.define("teams", {}, {
	    timestamp: true
	});
	
	/* Meetings model */
	/* A completer en fonction du rendez_vous avec l'equipe et/ou avec l'employé seul! */
	models.meetings = db.define("meetings", {
	    annual_meeting      : {type: 'date', time: true},
	    mid_annual_meeting  : {type: 'date', time: true},
	    resume              : {type: 'text'},
	}, {
	    timestamp: true
	});
	

	/* Phrases model*/
	models.phrases = db.define("phrases", {
	    text        : String,
	}, {
	    timestamp: true
	});
	
	/* Intermediate model for meetings */
	models.meetings_inter = db.define("meetings_inter", {});
	
	/* Associations */
	models.meetings_inter.hasOne('managers', models.managers, {reverse : "meeting"});
	models.meetings_inter.hasOne('employees', models.employees, {reverse : "meeting"});
	models.meetings_inter.hasOne('teams', models.teams, {reverse : "meetings"});
	models.employees.hasOne('teams', models.teams, {reverse : "employees"});
	models.teams.hasOne('managers', models.managers, {reverse : "teams"});
	

	db.sync(function(err) {
	    if (err) throw err;
	    
	});
	
	next();
    }
}));
